// eslint-disable-next-line function-paren-newline
import { Px } from './v1.00';

export const PxImage = Px.Image;
export const PxImageBackground = Px.ImageBackground;

export {
  Px
};
